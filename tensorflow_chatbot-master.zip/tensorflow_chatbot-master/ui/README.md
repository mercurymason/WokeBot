# Flask Chatbox

A simple flask application that provides an UI for chat and handles the model internally.
